#ifndef __POLINOMIO__HXX__
#define __POLINOMIO__HXX__

#include <iostream>
#include <vector>
#include <math.h>
#include "Polinomio.h"

using namespace std;

// -------------------------------------------------------------------------
template < class S > 
Polinomio<S>::
Polinomio( )
{
}

// -------------------------------------------------------------------------
template < class S > 
Polinomio<S>::
~Polinomio( )
{
}

// -------------------------------------------------------------------------
template < class S > 
void Polinomio<S>::FijarCoeficiente( unsigned int grado, const S& coeficiente )
{
  if( grado >= this->size( ) )
    this->resize( grado + 1, S( 0 ) );
  ( *this )[ grado ] = coeficiente;
}

// -------------------------------------------------------------------------
template < class S > 
Polinomio<S> Polinomio<S>::operator+( const Polinomio< S >& der ) const
{
  Polinomio<S> resultado;
  int num;
  // TODO #1
  //tamaño de polinomio es > al otro polinomio
  if(this->size() > der.size()){
    //Guarda la resta de ambos polinomio
    num = this->size()-der.size();
    for(int i=(this->size()-1);i>=num;i--){
      resultado.FijarCoeficiente(i, (*this)[i]);
    }
    for(int i=(der.size()-1);i>=0;i--){
      resultado.FijarCoeficiente(i, (*this)[i]+(der)[i]);
    }

  }else if(this->size()<der.size()){
    num = der.size()-this->size();
    for(int i=(der.size()-1);i>=num;i--){
      resultado.FijarCoeficiente(i, (der)[i]);
    }
    for(int i=(this->size()-1);i>=0;i--){
      resultado.FijarCoeficiente(i, (*this)[i]+(der)[i]);
    }
  }else{
    num = this->size();
    for(int i=0; i<num; i++){
      resultado.FijarCoeficiente(i, (*this)[i]+(der)[i]);
    }
  }
  return resultado;
}

// -------------------------------------------------------------------------
template < class S > 
Polinomio<S> Polinomio<S>::operator*( const Polinomio< S >& der ) const
{
  Polinomio<S> resultado;
  Polinomio<S> aux;
  int num;
  // TODO #2
  if(this->size()>der.size()){
    for(int i=0; i<this->size(); i++){
      for(int j=0; j<der.size(); j++){
        aux.FijarCoeficiente(i+j, (*this)[i]*(der)[j]);
        if(resultado.size()>=aux.size()){
          resultado = aux+resultado;
        }else{
          resultado.FijarCoeficiente(i+j, (*this)[i]*(der)[j]);
        }
        aux.clear();
      }
    }
  }else if(this->size()< der.size()){
    for(int i=0; i<der.size(); i++){
      for(int j=0; j<this->size(); j++){
        aux.FijarCoeficiente(i+j, (*this)[j]*(der)[i]);
        if(resultado.size()>=aux.size()){
          resultado = aux+resultado;
        }else{
          resultado.FijarCoeficiente(i+j, (*this)[j]*(der)[i]);
        }
        aux.clear();
      }
    }
  }else{
    num=this->size();
    for(int i=0;i<num;i++){
      for(int j=0;j<num;j++){
        aux.FijarCoeficiente(i+j, (*this)[i]*(der)[j]);
        if(resultado.size()>=aux.size()){
          resultado = aux+resultado;
        }else{
          resultado.FijarCoeficiente(i+j, (*this)[i]*(der)[j]);
        }
        aux.clear();
      }
    }
  }

  return resultado;
}

// -------------------------------------------------------------------------
template < class S > 
S Polinomio<S>::operator()( const S& x ) const
{
  S resultado = S( 0 );

  // TODO #3
  for(int i=0;i<this->size();i++){
    resultado+=(*this)[i]*pow(x, i);
  }

  return resultado;
}

#endif // __POLINOMIO__HXX__

// eof - Polinomio.hxx
